=== quup vCard Widget ===
Contributors: apostylee
Donate link: 
Tags: quup,social network,turkish,vcard,profile,info
Requires at least: 3.3
Tested up to: 3.5.1
Stable tag: 
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

With this widget you can easyly add http://quup.com social profile information.

== Description ==

With this widget you can easyly add http://quup.com social profile information. You can customize widget for UserName, width, margin. Widget displays Avatar, Display Name and Follower, Following, quup counts.

== Installation ==

1. Upload `quup-vcard-widget.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress.